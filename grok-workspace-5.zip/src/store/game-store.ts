import { create } from "zustand";
import { loadSave, writeSave, defaultSave, markRoomCleared, type SaveData } from "@/game/save";
import { MAX_SOULS, ROOMS, WORLDS, type HudSnap } from "@/game/types";

export type Screen =
  | "title"
  | "worlds"
  | "play"
  | "pause"
  | "shop"
  | "settings"
  | "how"
  | "install"
  | "ad"
  | "worldFail"
  | "roomClear"
  | "worldClear";

export type AdKind = "interstitial" | "rewarded-soul" | "rewarded-coins" | "rewarded-continue" | "rewarded-skip";

interface GameState {
  save: SaveData;
  screen: Screen;
  prevScreen: Screen;
  hud: HudSnap;
  session: number;
  playWorld: number;
  playRoom: number;
  adKind: AdKind | null;
  adReturn: Screen;
  toast: string | null;
  persist: () => void;
  setScreen: (s: Screen) => void;
  applyHud: (h: HudSnap) => void;
  startRun: (world?: number, room?: number) => void;
  nextRoom: () => void;
  failWorld: () => void;
  restartWorld: () => void;
  continueAd: () => void;
  addCoins: (n: number) => void;
  addSouls: (n: number) => void;
  buy: (cost: number, apply: (s: SaveData) => SaveData) => boolean;
  watchAd: (kind: AdKind) => void;
  finishAd: () => void;
  setLang: (lang: "ar" | "en") => void;
  setSetting: (patch: Partial<SaveData["settings"]>) => void;
  resetAll: () => void;
  setToast: (t: string | null) => void;
}

export const useGameStore = create<GameState>((set, get) => ({
  save: loadSave(),
  screen: "title",
  prevScreen: "title",
  hud: {
    souls: MAX_SOULS,
    coins: 0,
    world: 0,
    room: 0,
    signAr: null,
    signEn: null,
    deaths: 0,
    paused: false,
  },
  session: 0,
  playWorld: 0,
  playRoom: 0,
  adKind: null,
  adReturn: "title",
  toast: null,

  persist: () => writeSave(get().save),

  setScreen: (s) => set({ prevScreen: get().screen, screen: s }),

  applyHud: (h) => {
    if (h.paused && get().screen === "play") {
      set({ hud: h, screen: "pause" });
      return;
    }
    set({ hud: h, save: { ...get().save, souls: h.souls, coins: h.coins } });
  },

  startRun: (world = 0, room = 0) => {
    const save = { ...get().save, currentWorld: world, currentRoom: room, inRun: true, souls: get().save.souls || MAX_SOULS };
    if (save.souls <= 0) save.souls = MAX_SOULS;
    set({
      save,
      playWorld: world,
      playRoom: room,
      screen: "play",
      session: get().session + 1,
      hud: { ...get().hud, world, room, souls: save.souls, coins: save.coins, deaths: 0 },
    });
    writeSave(save);
  },

  nextRoom: () => {
    const { playWorld, playRoom, save } = get();
    const next = markRoomCleared(save, playWorld, playRoom);
    const worldDone = playRoom + 1 >= ROOMS;
    if (worldDone) {
      set({
        save: { ...next, souls: MAX_SOULS },
        screen: "worldClear",
        playWorld: playWorld + 1,
        playRoom: 0,
      });
      writeSave({ ...next, souls: MAX_SOULS });
      return;
    }
    set({
      save: next,
      playRoom: playRoom + 1,
      screen: "roomClear",
    });
    writeSave(next);
  },

  failWorld: () => {
    const save = { ...get().save, souls: 0, inRun: true, currentWorld: get().playWorld, currentRoom: 0 };
    set({ save, screen: "worldFail" });
    writeSave(save);
  },

  restartWorld: () => {
    const save = { ...get().save, souls: MAX_SOULS, inRun: true, currentWorld: get().playWorld, currentRoom: 0 };
    set({
      save,
      playRoom: 0,
      screen: "play",
      session: get().session + 1,
      hud: { ...get().hud, room: 0, souls: MAX_SOULS, deaths: 0 },
    });
    writeSave(save);
  },

  continueAd: () => {
    const save = { ...get().save, souls: 3 };
    set({ save, screen: "play", session: get().session + 1 });
    writeSave(save);
  },

  addCoins: (n) => {
    const save = { ...get().save, coins: get().save.coins + n };
    set({ save });
    writeSave(save);
  },

  addSouls: (n) => {
    const save = { ...get().save, souls: Math.min(MAX_SOULS + 5, get().save.souls + n) };
    set({ save, hud: { ...get().hud, souls: save.souls } });
    writeSave(save);
  },

  buy: (cost, apply) => {
    const { save } = get();
    if (save.coins < cost) return false;
    const next = apply({ ...save, coins: save.coins - cost });
    set({ save: next, hud: { ...get().hud, coins: next.coins, souls: next.souls } });
    writeSave(next);
    return true;
  },

  watchAd: (kind) => {
    if (get().save.adsRemoved && kind === "interstitial") {
      get().finishAd();
      return;
    }
    set({ adKind: kind, adReturn: get().screen, screen: "ad" });
  },

  finishAd: () => {
    const kind = get().adKind;
    set({ adKind: null });
    if (kind === "rewarded-soul") {
      get().addSouls(1);
      set({ screen: get().adReturn === "pause" ? "pause" : "play" });
      return;
    }
    if (kind === "rewarded-coins") {
      get().addCoins(25);
      set({ screen: get().adReturn });
      return;
    }
    if (kind === "rewarded-continue") {
      get().continueAd();
      return;
    }
    if (kind === "rewarded-skip") {
      get().nextRoom();
      const st = get();
      if (st.screen === "worldClear") return;
      st.startRun(st.playWorld, st.playRoom);
      return;
    }
    if (kind === "interstitial") {
      const st = get();
      st.startRun(st.playWorld, st.playRoom);
      return;
    }
    set({ screen: get().adReturn });
  },

  setLang: (lang) => {
    const save = { ...get().save, settings: { ...get().save.settings, lang } };
    set({ save });
    writeSave(save);
  },

  setSetting: (patch) => {
    const save = { ...get().save, settings: { ...get().save.settings, ...patch } };
    set({ save });
    writeSave(save);
  },

  resetAll: () => {
    const save = defaultSave();
    set({ save, screen: "title", playWorld: 0, playRoom: 0 });
    writeSave(save);
  },

  setToast: (t) => set({ toast: t }),
}));
