import {
  T,
  type LevelSpec,
  type MovingPlat,
  type Sign,
  type Tile,
  type TrollId,
} from "./types";

function mulberry(seed: number) {
  let s = seed | 0;
  return () => {
    s = (Math.imul(s, 1831565813) + 0xdeadbeef) | 0;
    const t = Math.imul(s ^ (s >>> 15), 1 | s);
    return ((t ^ (t >>> 7)) >>> 0) / 4294967296;
  };
}

class Grid {
  cols: number;
  rows: number;
  tiles: Uint8Array;
  constructor(cols: number, rows: number) {
    this.cols = cols;
    this.rows = rows;
    this.tiles = new Uint8Array(cols * rows);
  }
  i(x: number, y: number) {
    return y * this.cols + x;
  }
  in(x: number, y: number) {
    return x >= 0 && y >= 0 && x < this.cols && y < this.rows;
  }
  get(x: number, y: number): Tile {
    if (!this.in(x, y)) return T.SOLID;
    return this.tiles[this.i(x, y)] as Tile;
  }
  set(x: number, y: number, v: Tile) {
    if (this.in(x, y)) this.tiles[this.i(x, y)] = v;
  }
  rect(x: number, y: number, w: number, h: number, v: Tile) {
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) this.set(x + i, y + j, v);
  }
  border() {
    this.rect(0, 0, this.cols, 1, T.SOLID);
    this.rect(0, this.rows - 1, this.cols, 1, T.SOLID);
    this.rect(0, 0, 1, this.rows, T.SOLID);
    this.rect(this.cols - 1, 0, 1, this.rows, T.SOLID);
  }
  ground() {
    this.rect(1, this.rows - 2, this.cols - 2, 1, T.SOLID);
  }
}

const TROLLS: TrollId[][] = [
  ["none", "none", "none", "falseFloor", "fakeGoal", "reverse", "crumble", "lyingSign", "vanishFloor", "combo"],
  ["crumble", "falseFloor", "spikePop", "vanishFloor", "crumble", "fakeGoal", "lyingSign", "falseFloor", "crumble", "combo"],
  ["spikePop", "falseFloor", "boostSpike", "fakeCheck", "crumble", "spikePop", "lyingSign", "fakeGoal", "spikePop", "combo"],
  ["reverse", "swapLR", "cameraFlip", "mirrorCam", "fakeGoal", "reverse", "lyingSign", "swapLR", "cameraFlip", "combo"],
  ["vanishFloor", "falseFloor", "invisWall", "fakeGoal", "crumble", "vanishFloor", "lyingSign", "invisWall", "falseFloor", "combo"],
  ["gravity", "slowFall", "jumpCut", "fakeGoal", "falseFloor", "gravity", "crumble", "slowFall", "jumpCut", "combo"],
  ["iceBoost", "boostSpike", "crumble", "fakeGoal", "iceBoost", "falseFloor", "spikePop", "boostSpike", "iceBoost", "combo"],
  ["shrink", "tiny", "jumpCut", "falseFloor", "fakeGoal", "crumble", "shrink", "vanishFloor", "tiny", "combo"],
  ["lyingSign", "fakeGoal", "fakeWin", "fakeCheck", "falseFloor", "crumble", "vanishFloor", "lyingSign", "fakeWin", "combo"],
  ["timedDoor", "vanishFloor", "spikePop", "falseFloor", "timedDoor", "fakeGoal", "crumble", "lyingSign", "timedDoor", "combo"],
  ["darkness", "crumble", "invisWall", "fakeGoal", "vanishFloor", "falseFloor", "spikePop", "darkness", "lyingSign", "combo"],
  ["fakeGoal", "fakeWin", "crumble", "falseFloor", "vanishFloor", "fakeCheck", "invisWall", "fakeGoal", "crumble", "combo"],
  ["crumble", "spikePop", "falseFloor", "vanishFloor", "fakeGoal", "invisWall", "crumble", "spikePop", "falseFloor", "combo"],
  ["teleport", "crumble", "fakeGoal", "invisWall", "vanishFloor", "falseFloor", "teleport", "lyingSign", "crumble", "combo"],
  ["wind", "crumble", "boostSpike", "fakeGoal", "vanishFloor", "jumpCut", "falseFloor", "wind", "spikePop", "combo"],
  ["risingLava", "crumble", "timedDoor", "vanishFloor", "fakeGoal", "falseFloor", "spikePop", "risingLava", "crumble", "combo"],
  ["invisWall", "falseFloor", "crumble", "vanishFloor", "fakeGoal", "invisWall", "spikePop", "lyingSign", "falseFloor", "combo"],
  ["combo", "reverse", "darkness", "risingLava", "fakeWin", "gravity", "wind", "crumble", "vanishFloor", "combo"],
  ["fakeWin", "swapLR", "goalRuns", "crumble", "lockedJump", "vanishFloor", "cameraFlip", "falseFloor", "goalRuns", "combo"],
  ["combo", "reverse", "risingLava", "darkness", "goalRuns", "gravity", "crumble", "fakeWin", "vanishFloor", "combo"],
];

function parseAscii(lines: string[], world: number, room: number, trolls: TrollId[], signs: Sign[] = []): LevelSpec {
  const rows = lines.length;
  const cols = Math.max(...lines.map((l) => l.length));
  const g = new Grid(cols, rows);
  let spawn = { x: 2, y: rows - 4 };
  let goal = { x: cols - 3, y: rows - 4 };
  const moving: MovingPlat[] = [];
  for (let y = 0; y < rows; y++) {
    const line = lines[y]!.padEnd(cols, ".");
    for (let x = 0; x < cols; x++) {
      const c = line[x]!;
      switch (c) {
        case "#":
          g.set(x, y, T.SOLID);
          break;
        case "^":
          g.set(x, y, T.SPIKE_U);
          break;
        case "v":
          g.set(x, y, T.SPIKE_D);
          break;
        case "S":
          spawn = { x, y };
          break;
        case "G":
          goal = { x, y };
          g.set(x, y, T.GOAL);
          break;
        case "g":
          g.set(x, y, T.FAKE_GOAL);
          break;
        case "P":
          g.set(x, y, T.CRUMBLE);
          break;
        case "F":
          g.set(x, y, T.FAKE_SOLID);
          break;
        case "I":
          g.set(x, y, T.INVIS);
          break;
        case "i":
          g.set(x, y, T.ICE);
          break;
        case "B":
          g.set(x, y, T.BOUNCE);
          break;
        case "A":
          g.set(x, y, T.TELE_A);
          break;
        case "T":
          g.set(x, y, T.TELE_B);
          break;
        case "-":
          g.set(x, y, T.ONE_WAY);
          break;
        case "=":
          g.set(x, y, T.CONV_R);
          break;
        case "+":
          g.set(x, y, T.CONV_L);
          break;
        case "O":
          g.set(x, y, T.SPRING);
          break;
        case "o":
          g.set(x, y, T.COIN);
          break;
        case "L":
          g.set(x, y, T.LAVA);
          break;
        case "D":
          g.set(x, y, T.DOOR);
          break;
        case "K":
          g.set(x, y, T.BUTTON);
          break;
        case "H":
          g.set(x, y, T.HIDDEN_SPIKE);
          break;
        case "V":
          g.set(x, y, T.VANISH);
          break;
        case "X":
          g.set(x, y, T.SPIKE_POP);
          break;
        default:
          break;
      }
    }
  }
  return finish(g, world, room, trolls, spawn, goal, signs, moving);
}

function finish(
  g: Grid,
  world: number,
  room: number,
  trolls: TrollId[],
  spawn: { x: number; y: number },
  goal: { x: number; y: number },
  signs: Sign[],
  moving: MovingPlat[],
): LevelSpec {
  g.set(spawn.x, g.rows - 2, T.SOLID);
  g.set(goal.x, g.rows - 2, T.SOLID);
  const cap = gapCap(world, trolls);
  ensureWalk(g, spawn.x, goal.x, cap);
  armDisappearTraps(g);
  ensureWalk(g, spawn.x, goal.x, cap);
  g.set(spawn.x, g.rows - 2, T.SOLID);
  g.set(goal.x, g.rows - 2, T.SOLID);
  const has = (id: TrollId) => trolls.includes(id);
  return {
    cols: g.cols,
    rows: g.rows,
    tiles: g.tiles,
    world,
    room,
    trolls,
    spawn,
    goal,
    signs,
    moving,
    wind: has("wind") ? (world % 2 === 0 ? 140 : -140) : 0,
    gravitySign: 1,
    risingLava: has("risingLava"),
    darkness: has("darkness"),
    cameraFlip: has("cameraFlip"),
    mirrorCam: has("mirrorCam"),
    reverse: has("reverse"),
    swapLR: has("swapLR"),
    shrink: has("shrink") || has("tiny"),
    jumpCut: has("jumpCut"),
    lockedJump: has("lockedJump"),
    goalRuns: has("goalRuns"),
    fakeWin: has("fakeWin"),
    timedDoor: has("timedDoor"),
    vanishFloor: has("vanishFloor"),
  };
}

const TUTORIAL: string[][] = [
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "################################",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "##########...###################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "##########^^^###################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "#########FFFF###################",
    "#........^^^^..................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#.................g............#",
    "#................####..........#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "################################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............####............#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "#############...################",
    "#............^^^...............#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "#######PPPPPPP##################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "##########^^^###################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "##########VVV###################",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
  [
    "################################",
    "#..............................#",
    "#...................g..........#",
    "#..................####........#",
    "#..............................#",
    "#..............................#",
    "#S............................G#",
    "#######FFFF####PPPP#############",
    "#..............................#",
    "#..............................#",
    "#..............................#",
    "################################",
  ],
];

const TUTORIAL_SIGNS: Sign[][] = [
  [{ x: 10, y: 6, ar: "امشِ إلى الباب. بسيط.", en: "Walk to the door. Simple." }],
  [{ x: 12, y: 5, ar: "اقفز. المسافة تصدق هذه المرة.", en: "Jump. Space tells the truth this time." }],
  [{ x: 12, y: 5, ar: "الإبر سيئة. تجاوزها.", en: "Needles are rude. Go over." }],
  [{ x: 10, y: 5, ar: "الأرض صديقتك.", en: "The floor is your friend." }],
  [{ x: 14, y: 5, ar: "أقرب باب هو الباب.", en: "The nearest door is the door." }],
  [{ x: 12, y: 4, ar: "التحكم معكوس. أو لا.", en: "Controls are reversed. Or not." }],
  [{ x: 12, y: 4, ar: "قف طويلاً. الأرض تحبك.", en: "Stand still. The floor loves you." }],
  [{ x: 12, y: 4, ar: "لا تقفز.", en: "Do not jump here." }],
  [{ x: 14, y: 3, ar: "هذه الأرضية تبدو عادية.", en: "This floor looks ordinary." }],
  [{ x: 10, y: 3, ar: "الآن فهمت القواعد.", en: "Now you know the rules." }],
];

const WANE_ROOM4 = [
  "####################################",
  "#..................................#",
  "#..................................#",
  "#..................................#",
  "#..................................#",
  "#..................................#",
  "#..................................#",
  "#...........VVV....................#",
  "#S..............o................G.#",
  "#####..###PP..###VV..###X..###..####",
  "####################################",
];

const PHANTOM_ROOM0 = [
  "################################",
  "#..............................#",
  "#..............................#",
  "#..............................#",
  "#..............VVVV............#",
  "#..............................#",
  "#..............................#",
  "#..............................#",
  "#S...........o................G#",
  "#######LL########LL#############",
  "#..............................#",
  "################################",
];

const DUST_ROOM4 = [
  "################################",
  "#..............................#",
  "#..........VVVV................#",
  "#..............................#",
  "#..............................#",
  "#..............................#",
  "#S........o...................G#",
  "######...########...############",
  "#.....^^^........^^^...........#",
  "#..............................#",
  "#..............................#",
  "################################",
];

function trapUnder(g: Grid, x: number, y: number) {
  const by = y + 1;
  if (!g.in(x, by)) return;
  const cur = g.get(x, by);
  if (cur === T.GOAL || cur === T.FAKE_GOAL) {
    const by2 = by + 1;
    if (g.in(x, by2) && g.get(x, by2) !== T.GOAL && g.get(x, by2) !== T.FAKE_GOAL) {
      g.set(x, by2, T.HIDDEN_SPIKE);
    }
    return;
  }
  if (cur === T.HIDDEN_SPIKE) return;
  g.set(x, by, T.HIDDEN_SPIKE);
}

function armDisappearTraps(g: Grid) {
  for (let y = 0; y < g.rows - 1; y++) {
    for (let x = 0; x < g.cols; x++) {
      const t = g.get(x, y);
      if (t !== T.CRUMBLE && t !== T.VANISH) continue;
      trapUnder(g, x, y);
    }
  }
}

function applyTrollTiles(g: Grid, troll: TrollId, R: () => number, spawnX: number, goalX: number) {
  const mid = ((spawnX + goalX) / 2) | 0;
  const gy = g.rows - 2;
  if (troll === "falseFloor" || troll === "combo") {
    const w = 2 + ((R() * 2) | 0);
    const x = Math.max(spawnX + 4, mid - 1);
    for (let i = 0; i < w; i++) {
      if (g.get(x + i, gy) === T.SOLID) {
        g.set(x + i, gy, T.FAKE_SOLID);
        g.set(x + i, gy + 1, T.LAVA);
      }
    }
  }
  if (troll === "crumble" || troll === "combo") {
    const x = mid;
    for (let i = 0; i < 3; i++) {
      if (g.get(x + i, gy) === T.SOLID) {
        g.set(x + i, gy, T.CRUMBLE);
      }
    }
  }
  if (troll === "fakeGoal" || troll === "fakeWin" || troll === "combo") {
    const fx = Math.min(g.cols - 5, Math.max(spawnX + 6, mid));
    const fy = gy - 3;
    g.rect(fx - 1, fy + 1, 3, 1, T.SOLID);
    g.set(fx, fy, T.FAKE_GOAL);
  }
  if (troll === "invisWall") {
    const x = mid + 1;
    g.rect(x, gy - 3, 1, 2, T.INVIS);
  }
  if (troll === "iceBoost" || troll === "boostSpike") {
    g.rect(spawnX + 4, gy, 8, 1, T.ICE);
    if (troll === "boostSpike") g.set(spawnX + 12, gy - 1, T.SPIKE_U);
  }
  if (troll === "teleport") {
    g.set(spawnX + 5, gy - 1, T.TELE_A);
    g.set(goalX - 3, gy - 1, T.TELE_B);
  }
  if (troll === "spikePop") {
    for (let x = spawnX + 5; x < goalX - 3; x += 4) g.set(x, gy, T.SPIKE_POP);
  }
  if (troll === "timedDoor") {
    const doorX = Math.min(g.cols - 4, Math.max(spawnX + 8, mid));
    g.set(doorX, gy, T.SOLID);
    g.rect(doorX, gy - 2, 1, 2, T.DOOR);
    const bx = Math.max(2, doorX - 3);
    g.set(bx, gy, T.SOLID);
    g.set(bx, gy - 1, T.BUTTON);
  }
  if (troll === "vanishFloor") {
    const x = Math.min(g.cols - 8, Math.max(spawnX + 7, mid - 2));
    const py = Math.max(3, gy - 2);
    g.rect(x, py, 3, 1, T.VANISH);
  }
}

function trollsFor(world: number, room: number): TrollId[] {
  const raw = TROLLS[world]?.[room] ?? "none";
  if (raw !== "combo") {
    if (world >= 10 && raw !== "crumble" && raw !== "none") return [raw, "crumble"];
    return [raw];
  }
  const theme = (TROLLS[world] ?? []).find((id) => id !== "combo" && id !== "none") ?? "crumble";
  if (world >= 10) return [...new Set<TrollId>([theme, "fakeGoal", "crumble", "falseFloor", "vanishFloor"])];
  return [...new Set<TrollId>([theme, "fakeGoal", "crumble", "falseFloor"])];
}

function gapCap(world: number, trolls: TrollId[]) {
  const short = trolls.some(
    (t) => t === "jumpCut" || t === "gravity" || t === "shrink" || t === "tiny" || t === "slowFall",
  );
  if (short) return 2;
  if (world >= 14) return 3;
  if (world >= 6) return 3;
  return 2;
}

function generate(world: number, room: number): LevelSpec {
  const trolls = trollsFor(world, room);
  const troll = trolls[0] ?? "none";
  const R = mulberry(world * 10007 + room * 9176 + 13);
  const expert = world >= 10;
  const cols = expert ? 40 + (room % 3) * 2 : 34 + (room % 3) * 2;
  const rows = trolls.includes("risingLava") ? 18 : expert ? 16 : 14;
  const g = new Grid(cols, rows);
  g.border();
  const gy = rows - 2;
  const cap = gapCap(world, trolls);
  const pit: Tile = trolls.includes("spikePop") || world === 2 || (expert && room % 2 === 1) ? T.SPIKE_U : T.LAVA;
  const layout = (world + room * 3) % 5;

  g.rect(1, gy, cols - 2, 1, T.EMPTY);

  type Isle = { x: number; y: number; w: number };
  const isles: Isle[] = [];
  let x = 1;
  let y = gy;
  const islands = (expert ? 7 : 5) + (room % 3);
  g.rect(1, gy, 4, 1, T.SOLID);
  isles.push({ x: 1, y: gy, w: 4 });
  x = 5;

  for (let i = 0; i < islands && x < cols - 7; i++) {
    const gap = cap === 2 ? 2 : 2 + (R() > 0.62 ? 1 : 0);
    let rise = 0;
    if (layout === 1) rise = i % 4 === 1 ? 1 : i % 4 === 2 ? -1 : 0;
    else if (layout === 2) rise = i % 2 === 0 ? 1 : -1;
    else if (layout === 3 && i === Math.floor(islands / 2)) rise = 1;
    else if (layout === 4 && i % 3 === 1) rise = 1;
    if (trolls.includes("risingLava")) rise = i < islands - 1 ? 1 : 0;
    let ny = y - rise;
    if (ny < gy - (trolls.includes("risingLava") ? 5 : 3)) ny = y;
    if (ny > gy) ny = gy;
    if (ny < y - 1) ny = y - 1;
    if (ny > y + 2) ny = y + 1;
    const w = 3 + ((R() * (expert ? 2 : 3)) | 0);
    x += Math.min(cap, gap);
    if (x + w >= cols - 3) break;
    g.rect(x, ny, w, 1, T.SOLID);
    if (ny < gy) {
      for (let k = 0; k < w; k++) if (g.get(x + k, gy) === T.EMPTY) g.set(x + k, gy, pit);
    }
    isles.push({ x, y: ny, w });
    x += w;
    y = ny;
  }
  if (y < gy && x + 2 + 3 < cols - 2 && !trolls.includes("risingLava")) {
    x += Math.min(2, cap);
    g.rect(x, gy, 3, 1, T.SOLID);
    isles.push({ x, y: gy, w: 3 });
    x += 3;
  }
  if (x < cols - 2) {
    for (let i = x; i < cols - 2; ) {
      const hole = Math.min(cap, 2);
      const span = Math.min(4, cols - 3 - i);
      if (span <= 0) break;
      if (i > x) {
        for (let k = 0; k < hole && i < cols - 2; k++, i++) g.set(i, gy, pit);
      }
      const ww = Math.max(2, Math.min(span, cols - 2 - i));
      if (ww <= 0 || i >= cols - 2) break;
      g.rect(i, gy, ww, 1, T.SOLID);
      isles.push({ x: i, y: gy, w: ww });
      i += ww;
    }
  }

  const spawn = { x: 2, y: gy - 1 };
  const goal = { x: cols - 3, y: gy - 1 };
  if (trolls.includes("risingLava") && isles.length > 2) {
    let top = isles[0]!;
    for (const isle of isles) if (isle.y < top.y) top = isle;
    goal.x = Math.min(cols - 3, Math.max(2, top.x + top.w - 2));
    goal.y = Math.max(1, top.y - 1);
    g.rect(top.x, top.y, top.w, 1, T.SOLID);
  }
  g.set(goal.x, gy, T.SOLID);
  g.set(goal.x - 1, gy, T.SOLID);
  g.set(goal.x, goal.y, T.GOAL);
  g.set(spawn.x, gy, T.SOLID);
  g.set(spawn.x + 1, gy, T.SOLID);

  const spice = room % 5;
  for (let n = 1; n < isles.length - 1; n++) {
    const isle = isles[n]!;
    if (isle.y !== gy || isle.w < 3) continue;
    const mid = isle.x + 1;
    const last = isle.x + isle.w - 2;
    if (last <= mid) continue;
    const themeCrumb = world === 1 || trolls.includes("crumble");
    const themeFake = world === 4 || trolls.includes("falseFloor");
    const themePop = world === 2 || trolls.includes("spikePop");
    const themeIce = world === 6 || trolls.includes("iceBoost");
    if ((spice === 0 || themeCrumb) && n % 2 === 1) {
      for (let k = mid; k <= last; k++) g.set(k, gy, T.CRUMBLE);
    } else if ((spice === 1 || themeFake) && n % 2 === 0) {
      for (let k = mid; k <= Math.min(last, mid + 1); k++) {
        g.set(k, gy, T.FAKE_SOLID);
        g.set(k, gy + 1, T.LAVA);
      }
    } else if ((spice === 2 || themePop) && n % 3 === 0) {
      g.set(mid, gy, T.SPIKE_POP);
    } else if (themeIce && isle.w >= 4) {
      for (let k = isle.x; k < isle.x + isle.w; k++) if (g.get(k, gy) === T.SOLID) g.set(k, gy, T.ICE);
      if (isle.x + isle.w < cols - 2) g.set(isle.x + isle.w, gy, pit);
    } else if (spice === 3 && n === 2) {
      for (let k = mid; k <= Math.min(last, mid); k++) g.set(k, gy, T.VANISH);
    }
    if (expert && n % 2 === 0 && g.get(mid, gy) === T.SOLID) g.set(mid, gy, T.CRUMBLE);
  }

  if (!trolls.includes("risingLava") && isles.length > 3) {
    const host = isles[2]!;
    const bx = host.x;
    const by = Math.max(2, host.y - 2);
    if (g.get(bx, by) === T.EMPTY) {
      g.rect(bx, by, Math.min(3, host.w), 1, T.VANISH);
      if (R() > 0.4) g.set(bx + 1, by - 1, T.COIN);
    }
  }

  for (const tr of trolls) applyTrollTiles(g, tr, R, spawn.x, goal.x);

  if (trolls.includes("invisWall")) {
    const host = isles[Math.min(3, isles.length - 2)] ?? isles[1];
    if (host && host.w >= 3) g.set(host.x + 1, host.y - 1, T.INVIS);
  }

  g.set(spawn.x, gy, T.SOLID);
  g.set(spawn.x + 1, gy, T.SOLID);
  g.set(goal.x, gy, T.SOLID);
  g.set(goal.x, goal.y, T.GOAL);

  const moving: MovingPlat[] = [];
  if (world === 12 || world === 17 || (expert && room % 4 === 2)) {
    const host = isles[Math.min(2, isles.length - 1)]!;
    const mx = Math.min(cols - 8, host.x + host.w + 1);
    const my = Math.max(3, gy - 2);
    moving.push({
      x: mx * 32,
      y: my * 32,
      w: 3 * 32,
      h: 12,
      x0: mx * 32,
      x1: Math.min(cols - 5, mx + 4) * 32,
      y0: my * 32,
      y1: my * 32,
      period: expert ? 2.8 : 3.4,
      t: room * 0.4,
      carry: true,
    });
  }

  const signs: Sign[] = [];
  const lie = room % 2 === 0 || trolls.includes("lyingSign") || trolls.includes("vanishFloor") || trolls.includes("fakeGoal");
  if (lie) {
    const lies = [
      { ar: "المنصة العليا طريق مختصر.", en: "The upper shelf is a shortcut." },
      { ar: "هذه الأرض ثابتة.", en: "This floor will hold." },
      { ar: "اقفز الآن.", en: "Jump now." },
      { ar: "الباب القريب هو الصحيح.", en: "The near door is real." },
      { ar: "لا يوجد شيء تحتك.", en: "Nothing is under you." },
      { ar: "امشِ ببطء.", en: "Walk slowly." },
    ];
    const pick = lies[(world * 3 + room) % lies.length]!;
    signs.push({ x: Math.min(cols - 6, spawn.x + 5), y: gy - 2, ...pick });
  }

  return finish(g, world, room, trolls, spawn, goal, signs, moving);
}

function ensureWalk(g: Grid, spawnX: number, goalX: number, maxPit: number) {
  const gy = g.rows - 2;
  const walkable = (t: Tile) =>
    t === T.SOLID ||
    t === T.CRUMBLE ||
    t === T.ICE ||
    t === T.CONV_L ||
    t === T.CONV_R ||
    t === T.ONE_WAY ||
    t === T.SPRING ||
    t === T.BOUNCE ||
    t === T.SPIKE_POP ||
    t === T.VANISH;
  let run = 0;
  const x0 = 1;
  const x1 = g.cols - 2;
  for (let x = x0; x <= x1; x++) {
    if (walkable(g.get(x, gy))) run = 0;
    else {
      run++;
      if (run > maxPit) {
        g.set(x, gy, T.SOLID);
        run = 0;
      }
    }
  }
  void spawnX;
  void goalX;
}

export function getLevel(world: number, room: number): LevelSpec {
  const w = Math.max(0, Math.min(19, world | 0));
  const r = Math.max(0, Math.min(9, room | 0));
  if (w === 0) {
    return parseAscii(TUTORIAL[r]!, 0, r, trollsFor(0, r), TUTORIAL_SIGNS[r]);
  }
  if (w === 1 && r === 3) {
    return parseAscii(DUST_ROOM4, 1, 3, ["vanishFloor"], [
      { x: 12, y: 4, ar: "المنصة العليا هي الطريق.", en: "The upper shelf is the way." },
    ]);
  }
  if (w === 4 && r === 0) {
    return parseAscii(PHANTOM_ROOM0, 4, 0, ["falseFloor", "vanishFloor"], [
      { x: 11, y: 6, ar: "المنصة العليا طريق مختصر.", en: "The upper shelf is a shortcut." },
    ]);
  }
  if (w === 7 && r === 3) {
    return parseAscii(WANE_ROOM4, 7, 3, ["tiny", "falseFloor", "crumble"], [
      { x: 8, y: 5, ar: "الرف العلوي آمن.", en: "The shelf above is safe." },
    ]);
  }
  return generate(w, r);
}

export function tileSolid(t: Tile, falling: boolean, fromAbove: boolean, reveal = false): boolean {
  switch (t) {
    case T.SOLID:
    case T.CRUMBLE:
    case T.ICE:
    case T.BOUNCE:
    case T.SPRING:
    case T.CONV_L:
    case T.CONV_R:
    case T.VANISH:
    case T.DOOR:
    case T.SPIKE_POP:
      return true;
    case T.INVIS:
      return true;
    case T.ONE_WAY:
      return falling && fromAbove;
    case T.FAKE_SOLID:
      return false;
    default:
      return false;
  }
  void reveal;
}

export function looksSolid(t: Tile, hint: boolean): boolean {
  if (t === T.FAKE_SOLID) return !hint;
  if (t === T.INVIS) return hint;
  if (t === T.FAKE_GOAL || t === T.GOAL) return false;
  if (
    t === T.SPIKE_U ||
    t === T.SPIKE_D ||
    t === T.SPIKE_L ||
    t === T.SPIKE_R ||
    t === T.HIDDEN_SPIKE ||
    t === T.LAVA
  ) {
    return false;
  }
  return tileSolid(t, true, true);
}
