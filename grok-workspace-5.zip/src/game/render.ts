import { TILE, VIEW_H, VIEW_W, type LevelSpec, type Tile } from "./types";
import { T } from "./types";
import { WORLDS_INFO } from "./worlds";
import { looksSolid, tileSolid } from "./levels";

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
}

export interface DrawPlayer {
  x: number;
  y: number;
  w: number;
  h: number;
  facing: number;
  grounded: boolean;
  vx: number;
  vy: number;
  scale: number;
  squish: number;
  anim: "idle" | "run" | "jump" | "hurt";
  frame: number;
  flash: number;
  dead: boolean;
}

export interface Sprites {
  idle: HTMLImageElement | null;
  run: HTMLImageElement | null;
  jump: HTMLImageElement | null;
  hurt: HTMLImageElement | null;
}

function hash(x: number, y: number) {
  return Math.abs(Math.sin(x * 127.1 + y * 311.7) * 43758.5453) % 1;
}

export function drawWorld(
  ctx: CanvasRenderingContext2D,
  level: LevelSpec,
  camX: number,
  camY: number,
  t: number,
  hint: boolean,
  doorOpen: boolean,
  lavaY: number,
  particles: Particle[],
  player: DrawPlayer,
  sprites: Sprites,
  shake: { x: number; y: number },
  flip: boolean,
  mirror: boolean,
  darkness: boolean,
) {
  const theme = WORLDS_INFO[level.world]!;
  ctx.save();
  ctx.fillStyle = theme.sky[1];
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  const sky = ctx.createLinearGradient(0, 0, 0, VIEW_H);
  sky.addColorStop(0, theme.sky[0]);
  sky.addColorStop(1, theme.sky[1]);
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);

  ctx.save();
  ctx.translate(VIEW_W / 2, VIEW_H / 2);
  if (flip) ctx.scale(1, -1);
  if (mirror) ctx.scale(-1, 1);
  ctx.translate(-VIEW_W / 2, -VIEW_H / 2);
  ctx.translate(-camX + shake.x, -camY + shake.y);

  // parallax towers
  ctx.globalAlpha = 0.35;
  for (let i = 0; i < 8; i++) {
    const tx = i * 220 - (camX * 0.15) % 220;
    const th = 180 + ((i * 73) % 160);
    ctx.fillStyle = theme.solid;
    ctx.fillRect(tx + camX * 0.15, level.rows * TILE - th - 40, 70 + (i % 3) * 18, th);
    ctx.fillRect(tx + 20 + camX * 0.15, level.rows * TILE - th - 80, 16, 50);
  }
  ctx.globalAlpha = 1;

  const x0 = Math.max(0, Math.floor(camX / TILE) - 1);
  const y0 = Math.max(0, Math.floor(camY / TILE) - 1);
  const x1 = Math.min(level.cols, Math.ceil((camX + VIEW_W) / TILE) + 1);
  const y1 = Math.min(level.rows, Math.ceil((camY + VIEW_H) / TILE) + 1);

  for (let y = y0; y < y1; y++) {
    for (let x = x0; x < x1; x++) {
      const tile = level.tiles[y * level.cols + x] as Tile;
      if (tile === T.HIDDEN_SPIKE) continue;
      if (tile === T.SPIKE_U || tile === T.LAVA) {
        const above = y > 0 ? (level.tiles[(y - 1) * level.cols + x] as Tile) : T.EMPTY;
        if (looksSolid(above, hint) || tileSolid(above, true, true)) continue;
      }
      drawTile(ctx, tile, x, y, theme, t, hint, doorOpen);
    }
  }

  for (const m of level.moving) {
    ctx.fillStyle = theme.solidHi;
    roundRect(ctx, m.x, m.y, m.w, m.h, 4);
    ctx.fill();
    ctx.fillStyle = theme.accent;
    ctx.globalAlpha = 0.35;
    ctx.fillRect(m.x + 4, m.y + 2, m.w - 8, 3);
    ctx.globalAlpha = 1;
  }

  for (const s of level.signs) {
    ctx.fillStyle = "#2a241c";
    ctx.fillRect(s.x * TILE + 6, s.y * TILE + 4, TILE - 12, TILE - 8);
    ctx.strokeStyle = theme.accent;
    ctx.lineWidth = 1;
    ctx.strokeRect(s.x * TILE + 6.5, s.y * TILE + 4.5, TILE - 13, TILE - 9);
  }

  if (level.risingLava) {
    ctx.fillStyle = "rgba(180, 36, 48, 0.78)";
    ctx.fillRect(0, lavaY, level.cols * TILE, level.rows * TILE);
    ctx.fillStyle = "rgba(232, 120, 80, 0.5)";
    ctx.fillRect(0, lavaY, level.cols * TILE, 6);
  }

  for (const p of particles) {
    ctx.globalAlpha = Math.max(0, p.life / p.max);
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x, p.y, p.size, p.size);
  }
  ctx.globalAlpha = 1;

  drawPlayer(ctx, player, sprites, t);

  ctx.restore();

  if (darkness) {
    const px = player.x + player.w / 2 - camX + shake.x;
    const py = player.y + player.h / 2 - camY + shake.y;
    const g = ctx.createRadialGradient(px, py, 28, px, py, 160);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(0.45, "rgba(0,0,0,0.15)");
    g.addColorStop(1, "rgba(0,0,0,0.88)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  }

  ctx.fillStyle = theme.fog;
  ctx.fillRect(0, 0, VIEW_W, VIEW_H);
  ctx.restore();
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawTile(
  ctx: CanvasRenderingContext2D,
  tile: Tile,
  x: number,
  y: number,
  theme: (typeof WORLDS_INFO)[number],
  t: number,
  hint: boolean,
  doorOpen: boolean,
) {
  const px = x * TILE;
  const py = y * TILE;
  const solidLook = looksSolid(tile, hint);

  if (tile === T.EMPTY || tile === T.SPAWN) return;

  if (tile === T.FAKE_SOLID && hint) {
    ctx.fillStyle = "rgba(180,36,48,0.35)";
    ctx.fillRect(px, py, TILE, TILE);
    return;
  }
  if (tile === T.INVIS && !hint) return;
  if (tile === T.INVIS && hint) {
    ctx.strokeStyle = "rgba(232,224,212,0.5)";
    ctx.strokeRect(px + 1, py + 1, TILE - 2, TILE - 2);
    return;
  }

  if (
    tile === T.SOLID ||
    tile === T.CRUMBLE ||
    tile === T.VANISH ||
    tile === T.FAKE_SOLID ||
    tile === T.ICE ||
    tile === T.CONV_L ||
    tile === T.CONV_R ||
    tile === T.ONE_WAY ||
    tile === T.BOUNCE ||
    tile === T.SPRING ||
    tile === T.SPIKE_POP
  ) {
    if (!solidLook && tile === T.ONE_WAY) {
      ctx.fillStyle = theme.accent;
      ctx.globalAlpha = 0.5;
      ctx.fillRect(px, py, TILE, 6);
      ctx.globalAlpha = 1;
      return;
    }
    ctx.fillStyle = tile === T.ICE ? "#7aa0b8" : theme.solid;
    ctx.fillRect(px, py, TILE, TILE);
    const v = hash(x, y);
    ctx.fillStyle = theme.solidHi;
    ctx.globalAlpha = 0.25 + v * 0.2;
    ctx.fillRect(px + 2, py + 2, TILE - 4, 4);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = "rgba(0,0,0,0.35)";
    ctx.strokeRect(px + 0.5, py + 0.5, TILE - 1, TILE - 1);
    if (tile === T.CONV_R || tile === T.CONV_L) {
      ctx.fillStyle = theme.accent;
      const dir = tile === T.CONV_R ? 1 : -1;
      const ox = ((t * 40 * dir) % 12);
      ctx.fillRect(px + 8 + ox, py + 12, 8, 3);
    }
    if (tile === T.SPRING || tile === T.BOUNCE) {
      ctx.fillStyle = theme.accent;
      ctx.fillRect(px + 8, py + 8, TILE - 16, 6);
    }
    if (tile === T.SPIKE_POP && hint) {
      drawSpike(ctx, px, py, "#b4233a");
    }
    return;
  }

  if (tile === T.SPIKE_U || tile === T.HIDDEN_SPIKE) {
    if (tile === T.HIDDEN_SPIKE) return;
    drawSpike(ctx, px, py, theme.accent);
    return;
  }
  if (tile === T.SPIKE_D) {
    ctx.save();
    ctx.translate(px + 16, py + 16);
    ctx.rotate(Math.PI);
    ctx.translate(-16, -16);
    drawSpike(ctx, 0, 0, theme.accent);
    ctx.restore();
    return;
  }
  if (tile === T.LAVA) {
    const wobble = Math.sin(t * 7 + x * 1.3 + y) * 3;
    ctx.fillStyle = "#4a1018";
    ctx.fillRect(px, py, TILE, TILE);
    ctx.fillStyle = "#b4233a";
    ctx.fillRect(px, py + 4 + wobble, TILE, TILE);
    ctx.fillStyle = "#e07040";
    ctx.globalAlpha = 0.7;
    ctx.beginPath();
    ctx.ellipse(px + 10, py + 12 + wobble, 6, 3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#f0b070";
    ctx.globalAlpha = 0.45 + Math.sin(t * 9 + x) * 0.15;
    ctx.fillRect(px + 16, py + 8 + wobble, 8, 3);
    ctx.globalAlpha = 1;
    return;
  }
  if (tile === T.COIN) {
    ctx.fillStyle = theme.accent;
    ctx.beginPath();
    ctx.arc(px + 16, py + 16, 6 + Math.sin(t * 6 + x) * 1, 0, Math.PI * 2);
    ctx.fill();
    return;
  }
  if (tile === T.GOAL || tile === T.FAKE_GOAL) {
    const lie = tile === T.FAKE_GOAL && hint;
    ctx.fillStyle = lie ? "#b4233a" : theme.accent;
    ctx.fillRect(px + 4, py + 2, TILE - 8, TILE - 4);
    ctx.fillStyle = theme.sky[0];
    ctx.beginPath();
    ctx.moveTo(px + 8, py + 18);
    ctx.quadraticCurveTo(px + 16, py + 4, px + 24, py + 18);
    ctx.lineTo(px + 24, py + 28);
    ctx.lineTo(px + 8, py + 28);
    ctx.fill();
    ctx.fillStyle = lie ? "#b4233a" : "#e8c070";
    ctx.globalAlpha = 0.55 + Math.sin(t * 4) * 0.2;
    ctx.beginPath();
    ctx.arc(px + 16, py + 16, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
    return;
  }
  if (tile === T.CHECK || tile === T.FAKE_CHECK) {
    const lie = tile === T.FAKE_CHECK && hint;
    ctx.fillStyle = lie ? "#b4233a" : theme.accent;
    ctx.fillRect(px + 14, py + 8, 4, 20);
    ctx.beginPath();
    ctx.arc(px + 16, py + 10, 7, 0, Math.PI * 2);
    ctx.fillStyle = lie ? "#6e1826" : "#b4233a";
    ctx.fill();
    ctx.fillStyle = "#f0ebe3";
    ctx.globalAlpha = 0.5 + Math.sin(t * 5) * 0.3;
    ctx.beginPath();
    ctx.arc(px + 16, py + 10, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
    return;
  }
  if (tile === T.DOOR) {
    if (doorOpen) return;
    ctx.fillStyle = theme.solidHi;
    ctx.fillRect(px, py, TILE, TILE);
    ctx.fillStyle = theme.sky[0];
    ctx.fillRect(px + 8, py + 6, 16, 20);
    return;
  }
  if (tile === T.BUTTON) {
    ctx.fillStyle = theme.accent;
    ctx.fillRect(px + 8, py + 22, 16, 6);
    return;
  }
  if (tile === T.TELE_A || tile === T.TELE_B) {
    ctx.strokeStyle = tile === T.TELE_A ? theme.accent : "#b4233a";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(px + 16, py + 16, 8 + Math.sin(t * 5) * 2, 0, Math.PI * 2);
    ctx.stroke();
    return;
  }
}

function drawSpike(ctx: CanvasRenderingContext2D, px: number, py: number, color: string) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(px + 4, py + 30);
  ctx.lineTo(px + 16, py + 6);
  ctx.lineTo(px + 28, py + 30);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.beginPath();
  ctx.moveTo(px + 16, py + 6);
  ctx.lineTo(px + 22, py + 30);
  ctx.lineTo(px + 16, py + 30);
  ctx.fill();
}

function drawPlayer(ctx: CanvasRenderingContext2D, p: DrawPlayer, sprites: Sprites, time: number) {
  const sheet = sprites[p.anim] ?? sprites.idle;
  const dw = 36 * p.scale * (1 + p.squish * 0.15);
  const dh = 44 * p.scale * (1 - p.squish * 0.2);
  const dx = p.x + p.w / 2 - dw / 2;
  const dy = p.y + p.h - dh + 2;
  ctx.save();
  if (p.flash > 0 && Math.floor(time * 20) % 2 === 0) ctx.globalAlpha = 0.45;
  if (sheet && sheet.complete && sheet.naturalWidth > 0) {
    const fw = sheet.naturalWidth / 2;
    const fh = sheet.naturalHeight / 2;
    const col = p.frame % 2;
    const row = Math.floor(p.frame / 2) % 2;
    ctx.translate(dx + dw / 2, dy + dh / 2);
    ctx.scale(p.facing, 1);
    ctx.drawImage(sheet, col * fw, row * fh, fw, fh, -dw / 2, -dh / 2, dw, dh);
  } else {
    ctx.translate(dx + dw / 2, dy + dh / 2);
    ctx.scale(p.facing, 1);
    ctx.fillStyle = "#2a262c";
    ctx.fillRect(-dw / 2, -dh / 2 + 6, dw, dh - 8);
    ctx.fillStyle = "#f0ebe3";
    ctx.beginPath();
    ctx.ellipse(0, -dh / 2 + 12, 7, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#0a090c";
    ctx.fillRect(-3, -dh / 2 + 10, 2, 5);
    ctx.fillRect(2, -dh / 2 + 10, 2, 5);
    ctx.fillStyle = "#b4233a";
    ctx.beginPath();
    ctx.arc(dw / 2 - 6, 4, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function loadSprites(): Sprites {
  const load = (src: string) => {
    const img = new Image();
    img.src = src;
    return img;
  };
  return {
    idle: load("/sprites/wick-idle.png"),
    run: load("/sprites/wick-run.png"),
    jump: load("/sprites/wick-jump.png"),
    hurt: load("/sprites/wick-hurt.png"),
  };
}
