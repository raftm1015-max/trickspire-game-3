type Bus = { ctx: AudioContext; master: GainNode; sfx: GainNode; music: GainNode };

let bus: Bus | null = null;

function ensure(gesture = false): Bus | null {
  if (bus) {
    if (gesture && bus.ctx.state === "suspended") void bus.ctx.resume();
    return bus;
  }
  if (!gesture) return null;
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new Ctx({ latencyHint: "interactive" });
  const master = ctx.createGain();
  const sfx = ctx.createGain();
  const music = ctx.createGain();
  sfx.connect(master);
  music.connect(master);
  master.connect(ctx.destination);
  master.gain.value = 0.8;
  sfx.gain.value = 0.65;
  music.gain.value = 0.18;
  bus = { ctx, master, sfx, music };
  return bus;
}

export function unlockAudio() {
  ensure(true);
}

export function setVolumes(sfxVol: number, musicVol: number, muted = false) {
  const b = ensure(true);
  if (!b) return;
  const m = muted ? 0 : 1;
  b.sfx.gain.setTargetAtTime(sfxVol * sfxVol * m, b.ctx.currentTime, 0.03);
  b.music.gain.setTargetAtTime(musicVol * musicVol * m * 0.22, b.ctx.currentTime, 0.03);
}

function tone(
  freq: number,
  dur: number,
  type: OscillatorType,
  gain: number,
  slide = 0,
  dest: "sfx" | "music" = "sfx",
) {
  const b = bus;
  if (!b) return;
  const t = b.ctx.currentTime;
  const o = b.ctx.createOscillator();
  const g = b.ctx.createGain();
  const f = b.ctx.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.value = type === "sine" ? 1800 : 1200;
  o.type = type;
  o.frequency.setValueAtTime(Math.max(40, freq), t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + 0.018);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(f);
  f.connect(g);
  g.connect(dest === "music" ? b.music : b.sfx);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export const sfx = {
  jump: () => {
    tone(330, 0.14, "sine", 0.05, 140);
    tone(495, 0.1, "triangle", 0.025, 80);
  },
  step: () => tone(118 + Math.random() * 8, 0.05, "sine", 0.028, -18),
  land: () => tone(86, 0.07, "sine", 0.035, -20),
  death: () => {
    tone(196, 0.42, "triangle", 0.05, -90);
    tone(147, 0.5, "sine", 0.03, -50);
  },
  coin: () => {
    tone(660, 0.08, "sine", 0.04);
    tone(880, 0.12, "triangle", 0.03);
  },
  check: () => {
    tone(392, 0.12, "sine", 0.04);
    tone(523, 0.18, "triangle", 0.03);
  },
  goal: () => {
    tone(262, 0.16, "sine", 0.045);
    tone(330, 0.2, "triangle", 0.035);
    tone(392, 0.28, "sine", 0.03);
  },
  crumble: () => tone(72, 0.12, "triangle", 0.03, -22),
  pop: () => tone(210, 0.1, "sine", 0.03, 40),
  click: () => tone(520, 0.05, "sine", 0.03),
};

let musicTimer: number | null = null;
let musicOn = false;

export function startMusic() {
  const b = ensure(true);
  if (!b || musicOn) return;
  musicOn = true;
  const notes = [110, 130.81, 164.81, 146.83, 110, 98, 82.41, 98];
  let i = 0;
  const tick = () => {
    if (!musicOn || !bus) return;
    const n = notes[i % notes.length]!;
    const t = bus.ctx.currentTime;
    const o = bus.ctx.createOscillator();
    const g = bus.ctx.createGain();
    o.type = "sine";
    o.frequency.value = n;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.055, t + 0.12);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.05);
    o.connect(g);
    g.connect(bus.music);
    o.start(t);
    o.stop(t + 1.1);
    if (i % 4 === 0) {
      const o2 = bus.ctx.createOscillator();
      const g2 = bus.ctx.createGain();
      o2.type = "triangle";
      o2.frequency.value = n * 1.5;
      g2.gain.setValueAtTime(0.0001, t);
      g2.gain.exponentialRampToValueAtTime(0.018, t + 0.08);
      g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.7);
      o2.connect(g2);
      g2.connect(bus.music);
      o2.start(t);
      o2.stop(t + 0.75);
    }
    i++;
    musicTimer = window.setTimeout(tick, 780);
  };
  tick();
}

export function stopMusic() {
  musicOn = false;
  if (musicTimer != null) {
    clearTimeout(musicTimer);
    musicTimer = null;
  }
}

export function resumeAudio() {
  if (bus?.ctx.state === "suspended") void bus.ctx.resume();
}
