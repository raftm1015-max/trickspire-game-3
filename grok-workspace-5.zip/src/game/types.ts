export const TILE = 32;
export const FIXED_DT = 1 / 60;
export const VIEW_W = 960;
export const VIEW_H = 540;
export const WORLDS = 20;
export const ROOMS = 10;
export const MAX_SOULS = 10;

export const T = {
  EMPTY: 0,
  SOLID: 1,
  SPIKE_U: 2,
  SPIKE_D: 3,
  SPIKE_L: 4,
  SPIKE_R: 5,
  SPAWN: 6,
  GOAL: 7,
  FAKE_GOAL: 8,
  CHECK: 9,
  FAKE_CHECK: 10,
  CRUMBLE: 11,
  ICE: 12,
  BOUNCE: 13,
  TELE_A: 14,
  TELE_B: 15,
  HIDDEN_SPIKE: 16,
  ONE_WAY: 17,
  INVIS: 18,
  FAKE_SOLID: 19,
  SPRING: 20,
  COIN: 21,
  CONV_L: 22,
  CONV_R: 23,
  LAVA: 24,
  BUTTON: 25,
  DOOR: 26,
  SPIKE_POP: 27,
  VANISH: 28,
} as const;

export type Tile = (typeof T)[keyof typeof T];

export type TrollId =
  | "none"
  | "crumble"
  | "fakeGoal"
  | "reverse"
  | "vanishFloor"
  | "spikePop"
  | "fakeCheck"
  | "gravity"
  | "shrink"
  | "iceBoost"
  | "invisWall"
  | "teleport"
  | "cameraFlip"
  | "lyingSign"
  | "movingSpike"
  | "fakeWin"
  | "timedDoor"
  | "darkness"
  | "risingLava"
  | "wind"
  | "goalRuns"
  | "jumpCut"
  | "falseFloor"
  | "swapLR"
  | "tiny"
  | "lockedJump"
  | "mirrorCam"
  | "slowFall"
  | "boostSpike"
  | "combo";

export interface MovingPlat {
  x: number;
  y: number;
  w: number;
  h: number;
  x0: number;
  x1: number;
  y0: number;
  y1: number;
  period: number;
  t: number;
  carry: boolean;
}

export interface Sign {
  x: number;
  y: number;
  ar: string;
  en: string;
}

export interface LevelSpec {
  cols: number;
  rows: number;
  tiles: Uint8Array;
  world: number;
  room: number;
  trolls: TrollId[];
  spawn: { x: number; y: number };
  goal: { x: number; y: number };
  signs: Sign[];
  moving: MovingPlat[];
  wind: number;
  gravitySign: number;
  risingLava: boolean;
  darkness: boolean;
  cameraFlip: boolean;
  mirrorCam: boolean;
  reverse: boolean;
  swapLR: boolean;
  shrink: boolean;
  jumpCut: boolean;
  lockedJump: boolean;
  goalRuns: boolean;
  fakeWin: boolean;
  timedDoor: boolean;
  vanishFloor: boolean;
}

export interface WorldInfo {
  id: number;
  nameAr: string;
  nameEn: string;
  tagAr: string;
  tagEn: string;
  sky: [string, string];
  solid: string;
  solidHi: string;
  accent: string;
  fog: string;
}

export interface HudSnap {
  souls: number;
  coins: number;
  world: number;
  room: number;
  signAr: string | null;
  signEn: string | null;
  deaths: number;
  paused: boolean;
}

export interface GameHooks {
  onHud: (h: HudSnap) => void;
  onDeath: (soulsLeft: number) => void;
  onRoomClear: (coins: number) => void;
  onWorldFail: () => void;
  onWorldClear: () => void;
  onCoin: (total: number) => void;
  onCheckpoint: () => void;
}
